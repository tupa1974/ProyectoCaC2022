
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author tupa1
 */
public class Persistencia {

    private Connection conexion;
    private ResultSet resultado;
    private PreparedStatement prepare;

    public String servidor, baseDatos, usuario, clave, ejecutar;

    public Connection conectarse() throws SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");

            servidor = "localhost:3306/";
            baseDatos = "proyectocac";
            usuario = "tupa";
            clave = "1234";
            conexion = DriverManager.getConnection("jdbc:mysql://"
                    + servidor
                    + baseDatos
                    + "?autoReconnect=true&useSSL=false",usuario,clave);
                   
                    
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Persistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
        return conexion;
    }

    public ResultSet consultaSQL(String busqueda) {
        try {
            prepare = conectarse().prepareStatement(busqueda);
            resultado = prepare.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(Persistencia.class.getName()).log(Level.SEVERE, null, ex);
        }

        return resultado;
    }

}
